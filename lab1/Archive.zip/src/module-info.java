module openWeather {
	requires json.simple;
}